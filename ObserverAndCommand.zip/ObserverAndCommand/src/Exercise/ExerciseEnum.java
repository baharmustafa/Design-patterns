package Exercise;

public enum ExerciseEnum {
Lie_Down,
Get_Up
}
