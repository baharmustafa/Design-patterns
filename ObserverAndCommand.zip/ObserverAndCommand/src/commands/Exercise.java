package commands;

public interface Exercise {
void performExercise();
}
